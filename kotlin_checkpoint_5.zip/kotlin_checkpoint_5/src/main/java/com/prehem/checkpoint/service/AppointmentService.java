package com.prehem.checkpoint.service;

import com.prehem.checkpoint.model.Appointment;
import com.prehem.checkpoint.repository.AppointmentRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AppointmentService {
    private final AppointmentRepository repo;

    public AppointmentService(AppointmentRepository repo) {
        this.repo = repo;
    }

    public List<Appointment> findAll() {
        return repo.findAll();
    }

    public Optional<Appointment> findById(Long id) {
        return repo.findById(id);
    }

    public Appointment save(Appointment appointment) {
        return repo.save(appointment);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }
}
