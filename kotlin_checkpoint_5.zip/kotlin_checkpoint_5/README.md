## Endpoints
GET /api/appointments
GET /api/appointments/<built-in function id>
POST /api/appointments
PUT /api/appointments/<built-in function id>
DELETE /api/appointments/<built-in function id>

Swagger UI: http://localhost:8080/swagger-ui/index.html
